#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#pragma warning(disable:4996)

int Longest_substring(char s1[256], char s2[256], char s3[256], char* buffer)
{
	const char *delim = " ";
	char* token;
	char S1[50][15];
	char S2[50][15];
	char S3[50][15];
	int n1, n2, n3;
	char final[20][15];
	int ficount = 0;
	int lenth[20];

	token = strtok(s1, delim);
	for (int i = 0; token != NULL; token = strtok(NULL, delim))
	{
		strcpy(S1[i], token);
		n1 = i;
		i++;
	}

	token = strtok(s2, delim);
	for (int i = 0; token != NULL; token = strtok(NULL, delim))
	{
		strcpy(S2[i], token);
		n2 = i;
		i++;
	}

	token = strtok(s3, delim);
	for (int i = 0; token != NULL; token = strtok(NULL, delim))
	{
		strcpy(S3[i], token);
		n3 = i;
		i++;
	}

	for (int i = 0; i <= n1; i++)
	{
		int flag = 0;
		for (int j = 0; j <= n2; j++)
		{
			if (strcmp(S1[i], S2[j]) == 0)
				flag = 1;
		}
		if (flag == 1)
		{
			for (int k = 0; k <= n3; k++)
			{
				if (strcmp(S1[i], S3[k]) == 0)
					flag = 2;
			}
			if (flag == 2)
			{
				strcpy(final[ficount], S1[i]);
				ficount++;
			}
		}
	}

	for (int i = 0; i < ficount; i++)
		lenth[i] = strlen(final[i]);
	int max = 0;
	for (int i = 0; i < ficount; i++)
		if (max < lenth[i])
			max = lenth[i];
	for (int i = 0; i < ficount; i++)
		if (lenth[i] == max)
		{
			strcat(buffer, final[i]);
			strcat(buffer, " \0");
		}

	return max;
}

int main()
{
	char s1[256], s2[256], s3[256];
	char buffer[256] = "";
	int MAX;
	scanf("%[^\n]", s1);
	getchar();
	scanf("%[^\n]", s2);
	getchar();
	scanf("%[^\n]", s3);
	getchar();
	MAX = Longest_substring(s1, s2, s3, buffer);
	if (MAX == 0)
		printf("NULL");
	else 
		printf("%s%d", buffer, MAX);
	return 0;
}