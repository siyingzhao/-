#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#pragma warning(disable:4996)

void shift_vector(int m, int* vector, int number)
{
	if (number < 0)
		for (; number < 0;)
			number += m;
	else if (number >= m)
		for (; number >= m;)
			number -= m;
	int final[101];
	int temp;
	for (int i = 0; i < m; i++)
	{
		temp = i + number;
		if (temp >= m)
			temp -= m;
		final[temp] = vector[i];
	}
	for (int k = 0; k < m; k++)
		vector[k] = final[k];
}

int main()
{
	int m;
	int arr[101];
	scanf("%d", &m);
	if (m <= 0 || m >= 100)
	{
		printf("ERROR");
		return 0;
	}
	int num, count;
	count = 0;
	char c;
	while (1)
	{
		scanf("%d", &num);
		c = getchar();
		arr[count++] = num;
		if (c == '\n')
			break;
	}

	int number;
	scanf("%d", &number);
	shift_vector(m, arr, number);
	for (int i = 0; i < m; i++)
		printf("%d ", arr[i]);
	return 0;
}