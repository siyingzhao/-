#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#pragma warning(disable:4996)

void bubbleSort(int data[], int count) {
	int temp;
	int pass = 1;
	int exchange = 1;             // �ӵ�һ�˿�ʼ
	while (pass < count && exchange == 1) {
		exchange = 0;                 // ĳ���Ƿ��н����ı�־����ʼΪ�޽���
		for (int j = count - 1; j >= pass; j--) //�����Ԫ�ؿ�ʼ����һ��δ����Ԫ��
			if (data[j - 1] > data[j]) {              //����Ҫ�������û�Ԫ��          
				temp = data[j - 1];
				data[j - 1] = data[j];
				data[j] = temp;

				exchange = 1;
			}
		pass++;
	}
}

void new_bubbleSort(int data[2][100], int count) {
	int temp;
	int pass = 1; 
	int exchange = 1;// �ӵ�һ�˿�ʼ
	while (pass < count && exchange == 1) {
		exchange = 0;// ĳ���Ƿ��н����ı�־����ʼΪ�޽���
		for (int j = count - 1; j >= pass; j--) //�����Ԫ�ؿ�ʼ����һ��δ����Ԫ��
			if (data[1][j - 1] > data[1][j]) { //����Ҫ�������û�Ԫ��          
				temp = data[0][j - 1];
				data[0][j - 1] = data[0][j];
				data[0][j] = temp;

				temp = data[1][j - 1];
				data[1][j - 1] = data[1][j];
				data[1][j] = temp;
				exchange = 1;
			}
		pass++;
	}
}

void order(int m, int n, int matrix[100][100])
{
	int arr[100];
	for (int i = 0; i <= n - 1; i++)
	{
		int k = 0;
		for (int j = 0; j <= m - 1; j++)
		{
			arr[k] = matrix[j][i];
			k++;
		}
		bubbleSort(arr, m);
		int p = 0;
		for (int j = 0; j <= m - 1; j++)
		{
			matrix[j][i] = arr[p];
			p++;
		}
	}
}

int main()
{
	int m, n;

	scanf("%d %d", &m, &n);
	if (m <= 0 || m >= 100 || n <= 0 || n >= 100)
	{
		printf("ERROR");
		return 0;
	}

	/*int** matrix = new int* [m];
	for (int i = 0; i < n; i++)
		matrix[i] = new int[n];*/
	int matrix[100][100];

	int num;
	char c;
	for (int i = 0; i <= m - 1; i++)
	{
		for (int k = 0; k <= n - 1;)
		{
			while (1)
			{
				scanf("%d", &num);
				c = getchar();
				matrix[i][k++] = num;
				if (c == '\n' || k == n)
					break;
			}
		}
	}
	
	order(m, n, matrix);

	int doublearr[2][100];
	for (int i = 0; i < n; i++)
	{
		doublearr[0][i] = i;
		int sum = 0;
		for (int j = 0; j < m; j++)
			sum += matrix[j][i];
		doublearr[1][i] = sum;
	}
	new_bubbleSort(doublearr, n);


	for (int i = 0; i <= m - 1; i++)
	{
		for (int k = 0; k <= n - 1;k++)
		{
				if (k == n - 1)
				{
					printf("%d\n", matrix[i][doublearr[0][k]]);
					break;
				}
				else 
					printf("%d ", matrix[i][doublearr[0][k]]);
		}
	}
	return 0;
}