#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#pragma warning(disable:4996)

int strdelete(char* s1, char* s2)
{
	char* token;
	char s3[100];
	token = strtok(s1, s2);
	strcpy(s3, "\0");
	for(;token != NULL;token = strtok(NULL, s2))
	{
		strcat(s3, token);
	}
	strcpy(s1, s3);
	return strlen(s3);
}

int main()
{
	char s1[100], s2[20];
	scanf("%s %s", s1, s2);
	int len = strdelete(s1, s2);
	printf("%s %d", s1, len);
	return 0;
}