#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#pragma warning(disable:4996)

char* strcattype(char* s1, char* s2, int type)
{
	if (type == 1)
	{
		strcat(s1, s2);
		return s1;
	}
	else
	{
		strcat(s2, s1);
		return s2;
	}
}

int main()
{
	char s1[256], s2[256];
	int type;
	scanf("%s %s %d", s1, s2, &type);
	strcattype(s1, s2, type);
	if (type == 1)
		printf("%s %d", s1, strlen(s1));
	else if (type == 2)
		printf("%s %d", s2, strlen(s2));
	return 0;
}