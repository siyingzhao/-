#pragma once
#include "iostream"
#include "iomanip"
using namespace std;

class Rect
{
private:
	float top;
	float left;
	float bottom;
	float right;

public:
	Rect(const float& top, const float& left, const float& bottom, const float& right) :
		top(top), left(left), bottom(bottom), right(right) {}

	float getArea() const
	{
		return (top - bottom) * (right - left);
	}
};

