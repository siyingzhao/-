#pragma once
#include "iostream"
#include "iomanip"
using namespace std;
class Person
{
private:
	int height;
	float weight;
public:
	Person(const int& height, const float& weight):
		height(height),weight(weight){}

	void showInfo()
	{
		cout << height << ',' << fixed << setprecision(2) << weight << endl;
	}
};

