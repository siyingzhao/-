#pragma once
#include "iostream"
#include "iomanip"
#pragma warning(disable:4996)
using namespace std;

class Shape
{
public:
	virtual float getArea() = 0;
	virtual float getPerim() = 0;
};

class Rectangle :public Shape
{
private:
	float width;
	float height;
public:
	float getArea()
	{
		return width * height;
	}
	float getPerim()
	{
		return 2 * (width + height);
	}
	Rectangle(const float& width, const float& height) :
		width(width), height(height) {}
};

class Circle :public Shape
{
private:
	float radius;
public:
	float getArea()
	{
		return 3.1415926 * radius * radius;
	}
	float getPerim()
	{
		return 2 * 3.1415926 * radius;
	}
	Circle(const float& radius) :radius(radius) {}
};