#include "Employee.h"
#pragma warning(disable:4996)

int main()
{
	char Name[11], City[11], Address[51], Postcode[11], new_name[11];
	cin.getline(Name, 11);
	cin.getline(City, 11);
	cin.getline(Address, 51);
	cin.getline(Postcode, 11);
	cin.getline(new_name, 11);
	Employee employee(Name, City, Address, Postcode);
	employee.display();
	employee.change_name(new_name);
	employee.display();
	return 0;
}