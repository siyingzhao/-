#pragma once
#include "iostream"
#include "iomanip"
#include "string.h"
#pragma warning(disable:4996)
using namespace std;

class Employee
{
private:
	char Name[11] = "";
	char City[11] = "";
	char Address[51] = "";
	char Postcode[11] = "";
public:
	Employee(char* name, char* city, char* address, char* postcode)
	{
		strcpy(Name, name);
		strcpy(City, city);
		strcpy(Address, address);
		strcpy(Postcode, postcode);
	}

	void display()
	{
		cout << "Name: " << Name << endl;
		cout << "City: " << City << endl;
		cout << "Address: " << Address << endl;
		cout << "Postcode: " << Postcode << endl;
	}

	void change_name(char*new_name)
	{
		strcpy(Name, new_name);
	}
};

