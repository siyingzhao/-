#include "iostream"
#include "iomanip"
using namespace std;
#pragma once


class Complex
{
private:
	float r, i;
public:
	Complex(float r,float i):r(r),i(i){}

	Complex(float r):r(r),i(0){}

	void add(const Complex c2)
	{
		r += c2.r;
		i += c2.i;
	}

	void show()
	{
		if (i >= 0)
			cout << fixed << setprecision(2) << r << " + " << i << 'i' << endl;
		else
			cout << fixed << setprecision(2) << r << " - " << -i << 'i' << endl;
	}
};

