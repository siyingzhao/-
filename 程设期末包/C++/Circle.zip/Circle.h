#pragma once
class Circle
{
private:
	float radius;
public:
	Circle():radius(0){}

	Circle(const float& radius):radius(radius){}

	float getArea()
	{
		return 3.1415926 * radius * radius;
	}
};

