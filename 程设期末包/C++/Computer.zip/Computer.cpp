#include "Computer.h"
#pragma warning(disable:4996)

int main()
{
	char temp[50] = "";
	int r, f;
	float v;
	char ram_type[30] = "";
	char cdrom_type[30]="";

	for (int i = 0; i < 3; i++)
	{
		cin >> temp;
		{
			if (strcmp(temp, "CPU") == 0)
				cin >> r >> f >> v;
			else if (strcmp(temp, "RAM") == 0)
				cin >> ram_type;
			else if (strcmp(temp, "CDROM") == 0)
				cin >> cdrom_type;
		}
	}
	Computer computer(r, f, v, ram_type, cdrom_type);

	computer.run();
	computer.stop();
	return 0;
}