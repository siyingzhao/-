#pragma once
#include "iostream"
#include "iomanip"
#include "string.h"
#pragma warning(disable:4996)
using namespace std;

//typedef enum CPU_Rank { P1 = 1, P2, P3, P4, P5, P6, P7 }Rank;

class CPU
{
private:
	int rank;
	int frequency;
	float voltage;
public:
	void run()
	{
		cout << "CPU RUN" << endl;
		cout << "CPU rank: P" << rank << endl;
		cout << "CPU frequency: " << frequency << " MHz" << endl;
		cout << "CPU voltage: " << fixed << setprecision(2) << voltage << " V" << endl;
	}

	void stop()
	{
		cout << "CPU STOP" << endl;
	}

	CPU(int r, int f, float v) :rank(r), frequency(f), voltage(v){}

};

class RAM
{
private:
	char type[30]="";
public:
	void run()
	{
		cout << "RAM RUN" << endl;
		cout << "RAM type: " << type << endl;
	}
	void stop()
	{
		cout << "RAM STOP" << endl;
	}
	RAM(const char* Type)
	{
		strcpy(type, Type);
	}
};

class CDROM
{
private:
	char type[30]="";
public:
	void run()
	{
		cout << "CDROM RUN" << endl;
		cout << "CDROM type: " << type << endl;
	}
	void stop()
	{
		cout << "CDROM STOP" << endl;
	}
	CDROM(const char* Type)
	{
		strcpy(type, Type);
	}
};

class Computer
{
private:
	CPU cpu;
	RAM ram;
	CDROM cdrom;
public:
	Computer(int r, int f, float v, char* ram_type, char* cdrom_type) :cpu(r, f, v), ram(ram_type), cdrom(cdrom_type) {}
	
	void run()
	{
		cout << "Computer RUN" << endl;
		cpu.run();
		ram.run();
		cdrom.run();
	}
	void stop()
	{
		cdrom.stop();
		ram.stop();
		cpu.stop();
		cout << "Computer STOP" << endl;
	}
};


