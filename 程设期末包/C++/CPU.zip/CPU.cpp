#include "CPU.h"

int main()
{
	int r, f;
	float v;
	cin >> r >> f >> v;
	CPU cpu(static_cast<CPU_Rank>(r), f, v);
	cpu.run();
	cpu.stop();
	return 0;
}
