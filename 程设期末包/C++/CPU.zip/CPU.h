#include <iostream>
#include <iomanip>
#pragma once

using namespace std;

typedef enum CPU_Rank { P1 = 1, P2, P3, P4, P5, P6, P7 }Rank;

class CPU
{
private:
	Rank rank;
	int frequency;
	float voltage;
public:
	void run()
	{
		cout << "CPU RUN" << endl;
		cout << "CPU rank: P" << rank << endl;
		cout << "CPU frequency: " << frequency << " MHz" << endl;
		cout << "CPU voltage: " << fixed << setprecision(2) << voltage << " V" << endl;
	}

	void stop()
	{
		cout << "CPU STOP" << endl;
	}

	CPU(Rank r,int f,float v):rank(r),frequency(f),voltage(v)
	{
		cout << "CPU Construct" << endl;
	}

	~CPU()
	{
		cout << "CPU Destroy" << endl;
	}
};

