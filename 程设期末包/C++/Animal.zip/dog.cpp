#include "dog.h"

int main()
{
	dog DOG;
	DOG.SetAge(3);
	return 0;
}