#pragma once
#include "iostream"
#include "iomanip"
#pragma warning(disable:4996)
using namespace std;

class Animal
{
public:
    int age;
};

class dog :
    public Animal
{
public:
    void SetAge(int n)
    {
        age = n;
    }
        
};

