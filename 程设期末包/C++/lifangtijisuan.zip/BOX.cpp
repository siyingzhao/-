#include "BOX.h"
#include "iostream"
using namespace std;

int main()
{
	int a;
	cin >> a;
	BOX box(a);
	cout << box.V() << ' ' << box.S() << endl;
	return 0;
}