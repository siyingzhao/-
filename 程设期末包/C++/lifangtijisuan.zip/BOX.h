#pragma once
class BOX
{
private:
	int a;
public:
	BOX():a(0){}

	BOX(const int&a):a(a){}

	int V()
	{
		return a * a * a;
	}

	int S()
	{
		return 6 * a * a;
	}
};

