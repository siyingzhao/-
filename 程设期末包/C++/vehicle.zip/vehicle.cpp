#include "vehicle.h"

int main()
{
	motorcycle M;
	
	return 0;
}