#pragma once
#include "iostream"
#include "iomanip"
#include "string.h"
#pragma warning(disable:4996)
using namespace std;

class CLIENT
{
private:
	char ServerName[20];
	long int ClientNum;
public:

	CLIENT()
	{
		strcpy(ServerName, "Server1");
		ClientNum = 0;
	}

	void ChangeServerName(const char* new_name)
	{
		strcpy(ServerName, new_name);
	}

	void add(int m)
	{
		ClientNum += m;
		if (ClientNum > 100000)
			ClientNum = 100000;
	}
	
	void sub(int m)
	{
		ClientNum -= m;
		if (ClientNum < 0)
			ClientNum = 0;
	}

	void print()
	{
		cout << "server name: " << ServerName << endl;
		cout << "client number: " << ClientNum << endl;
	}
};



