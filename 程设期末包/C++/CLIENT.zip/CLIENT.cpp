#include "CLIENT.h"

int main()
{
	CLIENT client;
	int n;
	cin >> n;
	char command[10] = "";
	char new_name[20] = "";
	int m;
	client.print();
	for (int i = 0; i < n; i++)
	{
		cin >> command;
		if (strcmp(command, "rename") == 0)
		{
			cin >> new_name;
			client.ChangeServerName(new_name);
		}
		else if (strcmp(command, "add") == 0)
		{
			cin >> m;
			client.add(m);
		}
		else if (strcmp(command, "sub") == 0)
		{
			cin >> m;
			client.sub(m);
		}
		client.print();
	}
	return 0;
}