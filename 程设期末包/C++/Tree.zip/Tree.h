#pragma once
class Tree
{
private:
	int ages;
public:
	Tree() :ages(0) {}

	Tree(const int& ages) :ages(ages) {}
	
	void grow(int year)
	{
		ages += year;
	}

	int age()
	{
		return ages;
	}
};

