#pragma once
#include "iostream"
#include "iomanip"
#pragma warning(disable:4996)
using namespace std;

class BaseClass
{
public:
	void fn1()
	{
		cout << "BaseClass fn1 run!" << endl;
	}
	void fn2()
	{
		cout << "BaseClass fn2 run!" << endl;
	}
};

