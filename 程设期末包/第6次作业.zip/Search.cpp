#include <stdio.h>
#include <string.h>
#pragma warning(disable:4996)

void find_matching_languages(char* pattern, char languages[][20], int count)
{
    for (int i = 0; i < count; i++) 
    {
        if (strstr(languages[i], pattern) != NULL)
            printf("%s\n", languages[i]);
    }
}

int main() 
{
    char languages[][20] = 
    {
        "C", "C++", "Python", "Java", "Basic", "C#", "PHP", "Javascript",
        "SQL", "Ruby", "Matlab", "Go", "Perl", "R", "Fortran", "Pascal", "Swift"
    };
    int count = sizeof(languages) / sizeof(languages[0]);
    char pattern[20];
    scanf("%s", pattern);
    find_matching_languages(pattern, languages, count);
    return 0;
}
