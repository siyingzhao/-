#include <stdio.h>
#pragma warning(disable:4996)


void shift_2d_matrix(int m, int n, int(*matrix)[100], int* number) 
{
    int temp[100][100];
    int shift_right = number[0] % n;
    int shift_down = number[1] % m;

    if (shift_right < 0) shift_right += n;
    if (shift_down < 0) shift_down += m;

    for (int i = 0; i < m; i++) 
    {
        for (int j = 0; j < n; j++) 
        {
            int new_i = (i + shift_down) % m;
            int new_j = (j + shift_right) % n;
            temp[new_i][new_j] = matrix[i][j];
        }
    }

    for (int i = 0; i < m; i++) 
    {
        for (int j = 0; j < n; j++) 
        {
            matrix[i][j] = temp[i][j];
        }
    }
}

int main()
{
    int m, n;
    scanf("%d %d", &m, &n);

    if (m <= 0 || m >= 100 || n <= 0 || n >= 100) 
    {
        printf("ERROR\n");
        return 0;
    }

    int matrix[100][100];
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++) 
            scanf("%d", &matrix[i][j]);
    }

    int number[2];
    scanf("%d %d", &number[0], &number[1]);

    shift_2d_matrix(m, n, matrix, number);

    for (int i = 0; i < m; i++) 
    {
        for (int j = 0; j < n; j++) 
            printf("%d ", matrix[i][j]);
        printf("\n");
    }
    return 0;
}
