#include <stdio.h>
#pragma warning(disable:4996)

void transpose(int m, int n, int(*matrix)[100], int(*result)[100]) 
{
    for (int i = 0; i < m; i++) 
    {
        for (int j = 0; j < n; j++) 
        {
            result[j][i] = matrix[i][j];
        }
    }
}

void multiply(int m, int n, int p, int q, int(*matrix1)[100], int(*matrix2)[100], int(*result)[100]) 
{
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < q; j++) 
        {
            result[i][j] = 0;
            for (int k = 0; k < n; k++) 
                result[i][j] += matrix1[i][k] * matrix2[k][j];
        }
    }
}

int main() 
{
    int m, n, p, q;
    scanf("%d %d", &m, &n);
    scanf("%d %d", &p, &q);

    if (m <= 0 || m >= 100 || n <= 0 || n >= 100 || p <= 0 || p >= 100 || q <= 0 || q >= 100) 
    {
        printf("ERROR\n");
        return 0;
    }

    int matrixA[100][100], matrixB[100][100], transposedB[100][100], result[100][100];

    for (int i = 0; i < m; i++) 
    {
        for (int j = 0; j < n; j++) 
        {
            scanf("%d", &matrixA[i][j]);
        }
    }

    for (int i = 0; i < p; i++) 
    {
        for (int j = 0; j < q; j++) 
        {
            scanf("%d", &matrixB[i][j]);
        }
    }

    transpose(p, q, matrixB, transposedB);

    for (int i = 0; i < q; i++) 
    {
        for (int j = 0; j < p; j++) 
            printf("%d ", transposedB[i][j]);
        printf("\n");
    }

    if (n != q) 
    {
        printf("INVALID\n");
        return 0;
    }

    multiply(m, n, q, p, matrixA, transposedB, result);

    for (int i = 0; i < m; i++) 
    {
        for (int j = 0; j < p; j++) 
            printf("%d ", result[i][j]);
        printf("\n");
    }
    return 0;
}