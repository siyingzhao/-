#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#pragma warning(disable:4996)

int minus(char ch)
{
	if (ch == '+')
		return 0;
	else if (ch == '-')
		return 1;
}

int turnum(char ch)
{
	return (ch - '0');
}

int judgenum(char ch)
{
	return (ch >= '1' && ch <= '9');
}

void analysis(char* s, int vector[])
{
	//�������
	int len = strlen(s) - 1;
	if (judgenum(s[len]) && s[len - 1] != '^')
	{
		if (minus(s[len - 1]))
			vector[0] = 0 - turnum(s[len]);
		else vector[0] = turnum(s[len]);
	}
	else
		vector[0] = 0;
	//xһ�η����
	int k;
	if (vector[0] == 0)
		k = len;
	else
		k = len - 2;
	if (s[k] == 'x')
	{
		if (judgenum(s[k - 1]))
		{
			if (minus(s[k - 2]))
				vector[1] = 0 - turnum(s[k - 1]);
			else vector[1] = turnum(s[k - 1]);
			k -= 3;
		}
		else
		{
			if (minus(s[k - 1]))
				vector[1] = -1;
			else vector[1] = 1;
			k -= 2;
		}
	}
	//�����η���������˵�һ�
	for (; k >= 3; k--)
	{
		if (s[k] == '^')
		{
			int index = turnum(s[k + 1]);
			if (judgenum(s[k - 2]))
			{
				if (minus(s[k - 3]))
					vector[index] = 0 - turnum(s[k - 2]);
				else vector[index] = turnum(s[k - 2]);
			}
			else
			{
				if (minus(s[k - 2]))
					vector[index] = -1;
				else vector[index] = 1;
			}
		}
	}
	//��һ���
	if (s[2] == '^')
	{
		int index = turnum(s[3]);
		if (judgenum(s[0]))
			vector[index] = turnum(s[0]);
		else vector[index] = -1;
	}
	if (s[1] == '^')
	{
		vector[turnum(s[2])] = 1;
	}
}

int polycomb(char* s1, char* s2, char* buffer)
{
	int vector1[60], vector2[60], sumvector[60];
	for (int i = 0; i < 60; i++)
	{
		vector1[i] = 0;
		vector2[i] = 0;
	}
	analysis(s1, vector1);
	analysis(s2, vector2);
	for (int i = 0; i < 60; i++)
	{
		sumvector[i] = vector1[i] + vector2[i];
	}
	int max;
	for (int i = 59; i >= 0; i--)
	{
		if (sumvector[i] != 0)
		{
			max = i;
			break;
		}
	}
	int count = max;
	//��һ��
	char temp[5];
	if (sumvector[max] == 1)
	{
		strcpy(buffer, "x^");
		sprintf(temp, "%d", max);
		strcat(buffer, temp);
	}
	else if (sumvector[max] == -1)
	{
		strcpy(buffer, "-x^");
		sprintf(temp, "%d", max);
		strcat(buffer, temp);
	}
	else
	{
		sprintf(temp, "%d", sumvector[max]);
		strcpy(buffer, temp);
		char temp2[5];
		strcat(buffer, "x^");
		sprintf(temp2, "%d", max);
		strcat(buffer, temp2);
	}
	//�м���
	for (int p = max - 1; p >= 2; p--)
	{
		if (sumvector[p] == 0)
			continue;
		char temp3[5];
		if (sumvector[p] == 1)
			strcat(buffer, "+");
		else if (sumvector[p] == -1)
			strcat(buffer, "-");
		else if (sumvector[p] > 0)
		{
			strcat(buffer, "+");
			sprintf(temp3, "%d", sumvector[p]);
			strcat(buffer, temp3);
		}
		else if (sumvector[p] < 0)
		{
			sprintf(temp3, "%d", sumvector[p]);
			strcat(buffer, temp3);
		}
		strcat(buffer, "x^");
		char temp4[5];
		sprintf(temp4, "%d", p);
		strcat(buffer, temp4);
	}
	//xһ����
	if (sumvector[1] != 0)
	{
		char temp5[5];
		if (sumvector[1] == 1)
			strcat(buffer, "+");
		else if (sumvector[1] == -1)
			strcat(buffer, "-");
		else if (sumvector[1] > 0)
		{
			strcat(buffer, "+");
			sprintf(temp5, "%d", sumvector[1]);
			strcat(buffer, temp5);
		}
		else if (sumvector[1] < 0)
		{
			sprintf(temp5, "%d", sumvector[1]);
			strcat(buffer, temp5);
		}
		strcat(buffer, "x");
	}
	//������
	if (sumvector[0] != 0)
	{
		if (sumvector[0] > 0)
		{
			char temp6[5];
			strcat(buffer, "+");
			sprintf(temp6, "%d", sumvector[0]);
			strcat(buffer, temp6);
		}
		else 
		{
			char temp7[5];
			sprintf(temp7, "%d", sumvector[0]);
			strcat(buffer, temp7);
		}
	}
	return sumvector[max];
}

int main()
{
	char s1[100], s2[100], sum[100];
	scanf("%s", s1);
	scanf("%s", s2);
	int max = polycomb(s1, s2, sum);
	printf("%s %d", sum, max);
	return 0;
}