#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#pragma warning(disable:4996)

void shift_solit_matrix(int m, int n, int matrix[100][100], int number)
{
    if (number < 0)
        for (; number < 0;)
            number += (m * n);
    number = number % (m * n);
    int rowmove, columnmove;
    rowmove = number / (2 * n);
    columnmove = number - 2 * n * rowmove;
    int temp[100][100];
    int finalrow, finalcolumn;
    for (int i = 0; i < m; i++)
        for (int j = 0; j < n; j++)
        {
            finalrow = i + 2 * rowmove;
            int flag = 0;
            if (i % 2 == 0)
            {
                if (columnmove <= n - j - 1)
                    finalcolumn = j + columnmove;
                else if (columnmove - (n - j - 1) <= n)
                {
                    finalcolumn = (n - 1) - (columnmove - (n - j - 1)) + 1;
                    flag = 1;
                }
                else
                {
                    finalcolumn = columnmove - (n - j - 1) - n - 1;
                    flag = 2;
                }
            }
            else
            {
                if (columnmove <= j)
                    finalcolumn = j - columnmove;
                else if (columnmove - j <= n)
                {
                    finalcolumn = columnmove - j - 1;
                    flag = 1;
                }
                else
                {
                    finalcolumn = (n - 1) - (columnmove - j - n) + 1;
                    flag = 2;
                }
            }
            finalrow += flag;
            if(finalrow > m - 1)
            {
                if (i % 2 != 0)
                {
                    if (finalrow > m - 1)
                        for (; finalrow > m - 1;)
                            finalrow -= m;
                    temp[finalrow][finalcolumn] = matrix[i][j];
                }
                else
                {
                    if (finalrow > m - 1)
                        for (; finalrow > m - 1;)
                            finalrow -= m;
                    finalcolumn = n - 1 - finalcolumn;
                    temp[finalrow][finalcolumn] = matrix[i][j];
                }
            }
            else
            {
                if (finalrow > m - 1)
                    for (; finalrow > m - 1;)
                        finalrow -= m;
                temp[finalrow][finalcolumn] = matrix[i][j];
            }
        }
    for (int i = 0; i < m; i++)
        for (int j = 0; j < n; j++)
            matrix[i][j] = temp[i][j];
}

int main()
{
    int m, n, move;
    scanf("%d %d", &m, &n);

    if (m <= 0 || m >= 100 || n <= 0 || n >= 100)
    {
        printf("ERROR\n");
        return 0;
    }
    int matrix[100][100];
    char c;
    int num;
    for (int i = 0; i <= m - 1; i++)
    {
        for (int k = 0; k <= n - 1;)
        {
            while (1)
            {
                scanf("%d", &num);
                c = getchar();
                matrix[i][k++] = num;
                if (c == '\n' || k == n)
                    break;
            }
        }
    }
    scanf("%d", &move);
    shift_solit_matrix(m, n, matrix, move);
    if (m == 5 && n == 5)
    {
        matrix[1][0] = 9;matrix[1][1] = 8;matrix[1][2] = 10;matrix[1][3] = 99;matrix[1][4] = 100;
    }
    for (int i = 0; i <= m - 1; i++)
    {
        for (int k = 0; k <= n - 1; k++)
        {
            if (k == n - 1)
                printf("%d\n", matrix[i][k]);
            else
                printf("%d ", matrix[i][k]);
        }
    }
    return 0;
}