#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#pragma warning(disable:4996)

int int2call(int amount, char* buffer)
{
	
	char trans[32][12];
	{
		strcpy(trans[1], "ONE");
		strcpy(trans[2], "TWO");
		strcpy(trans[3], "THREE");
		strcpy(trans[4], "FOUR");
		strcpy(trans[5], "FIVE");
		strcpy(trans[6], "SIX");
		strcpy(trans[7], "SEVEN");
		strcpy(trans[8], "EIGHT");
		strcpy(trans[9], "NINE");
		strcpy(trans[10], "TEN");
		strcpy(trans[11], "ELEVEN");
		strcpy(trans[12], "TWELVE");
		strcpy(trans[13], "THIRTEEN");
		strcpy(trans[14], "FOURTEEN");
		strcpy(trans[15], "FIFTEEN");
		strcpy(trans[16], "SIXTEEN");
		strcpy(trans[17], "SEVENTEEN");
		strcpy(trans[18], "EIGHTEEN");
		strcpy(trans[19], "NINETEEN");
		strcpy(trans[22], "TWENTY");
		strcpy(trans[23], "THIRTY");
		strcpy(trans[24], "FORTY");
		strcpy(trans[25], "FIFTY");
		strcpy(trans[26], "SIXTY");
		strcpy(trans[27], "SEVENTY");
		strcpy(trans[28], "EIGHTY");
		strcpy(trans[29], "NINETY");
	}

	if (amount > 0 && amount < 20)
	{
		strcpy(buffer, trans[amount]);
		return strlen(buffer);
	}
	else if (amount < 100)
	{
		int mod;
		mod = amount % 10;
		amount = (amount - mod) / 10;
		if (mod == 0)
			strcpy(buffer, trans[20 + amount]);
		else
		{
			strcpy(buffer, trans[20 + amount]);
			strcat(buffer, " ");
			strcat(buffer, trans[mod]);
		}
		return strlen(buffer);
	}
	else if (amount < 1000)
	{
		int mod1, mod2;
		mod1 = amount / 100;
		strcpy(buffer, trans[mod1]);
		strcat(buffer, " ");
		strcat(buffer, "HUNDRED");
		strcat(buffer, " ");
		amount = amount - 100 * mod1;
		if (amount < 20 && amount != 0)
		{
			strcat(buffer, trans[amount]);
			return strlen(buffer);
		}
		if (amount == 0)
		{
			return strlen(buffer);
		}
		mod2 = amount % 10;
		amount = (amount - mod2) / 10;
		if (mod2 == 0)
			strcat(buffer, trans[20 + amount]);
		else
		{
			strcat(buffer, trans[20 + amount]);
			strcat(buffer, " ");
			strcat(buffer, trans[mod2]);
		}
		return strlen(buffer);
	}
	else
	{

		int title = amount / 1000;
		if (title < 20)
		{
			strcpy(buffer, trans[title]);
			strcat(buffer, " THOUSAND ");
		}
		else if (title >= 20)
		{
			int modtitle;
			modtitle = title % 10;
			title = (title - modtitle) / 10;
			if (modtitle == 0)
			{
				strcpy(buffer, trans[20 + title]);
				strcat(buffer, " THOUSAND ");
			}
			else
			{
				strcpy(buffer, trans[20 + title]);
				strcat(buffer, " ");
				strcat(buffer, trans[modtitle]);
				strcat(buffer, " THOUSAND ");
			}
		}

		amount -= 1000 * title;
		if (amount >= 100)
		{
			int mod1, mod2;
			mod1 = amount / 100;
			strcat(buffer, trans[mod1]);
			strcat(buffer, " ");
			strcat(buffer, "HUNDRED");
			strcat(buffer, " ");
			amount = amount - 100 * mod1;
			if (amount < 20 && amount != 0)
			{
				strcat(buffer, trans[amount]);
				return strlen(buffer);
			}
			if (amount == 0)
			{
				return strlen(buffer);
			}
			mod2 = amount % 10;
			amount = (amount - mod2) / 10;
			if (mod2 == 0)
				strcat(buffer, trans[20 + amount]);
			else
			{
				strcat(buffer, trans[20 + amount]);
				strcat(buffer, " ");
				strcat(buffer, trans[mod2]);
			}
		}
		else if (amount >= 20)
		{
			int mod;
			mod = amount % 10;
			amount = (amount - mod) / 10;
			if (mod == 0)
				strcat(buffer, trans[20 + amount]);
			else
			{
				strcat(buffer, trans[20 + amount]);
				strcat(buffer, " ");
				strcat(buffer, trans[mod]);
			}
			return strlen(buffer);
		}
		else if (amount < 20)
		{
			strcat(buffer, trans[amount]);
			return strlen(buffer);
		}
		return strlen(buffer);
	}
}

int main()
{
	int amount;
	scanf("%d", &amount);
	if (amount <= 0 || amount >= 65535)
	{
		printf("ERROR");
		return 0;
	}
	char call[100];
	int2call(amount, call);
	printf("%s", call);
	return 0;
}