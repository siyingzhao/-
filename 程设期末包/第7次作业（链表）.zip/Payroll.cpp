#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#pragma warning(disable:4996)

typedef struct sal_count
{
	char id[11];
	char name[11];
	int sal;
	struct sal_count* next;
}Salcount;

Salcount* creatnode(const char* id, const char* name, int sal)
{
	Salcount* newnode = (Salcount*)malloc(sizeof(Salcount));
	if (!newnode)
	{
		printf("Error\n");
		exit(EXIT_FAILURE);
	}
	strcpy(newnode->id, id);
	newnode->id[10] = '\0';
	strcpy(newnode->name, name);
	newnode->name[10] = '\0';
	newnode->sal = sal;

	newnode->next = NULL;
	return newnode;
}

void appendnode(Salcount** head)
{
	char str[50];
	fgets(str, sizeof(str), stdin);
	str[strcspn(str, "\n")] = 0;
	char id[11], name[11];
	int sal;
	sscanf(str, "%s %s %d", id, name, &sal);
	Salcount* newnode = creatnode(id, name, sal);
	if (*head == NULL)
	{
		*head = newnode;
		return;
	}
	Salcount* temp = *head;
	while (temp->next != NULL)
		temp = temp->next;
	temp->next = newnode;
}


void printlist(Salcount* head)
{
	Salcount* temp = head;
	while (temp != NULL)
	{
		printf("{%s, %s, %d}\n", temp->id, temp->name, temp->sal);
		temp = temp->next;
	}
}

void sortList(Salcount** head)
{
	Salcount* current = *head, * index = NULL;
	char temp_id[11], temp_name[11];
	int temp_sal;

	if (*head == NULL) {
		return;
	}
	else {
		while (current != NULL) {
			index = current->next;

			while (index != NULL) {
				if (strcmp(current->id, index->id) > 0) {
					strcpy(temp_id, current->id);
					strcpy(temp_name, current->name);
					temp_sal = current->sal;

					strcpy(current->id, index->id);
					strcpy(current->name, index->name);
					current->sal = index->sal;

					strcpy(index->id, temp_id);
					strcpy(index->name, temp_name);
					index->sal = temp_sal;
				}
				index = index->next;
			}
			current = current->next;
		}
	}
}

void sortList2(Salcount** head)
{
	Salcount* current = *head, * index = NULL;
	char temp_id[11], temp_name[11];
	int temp_sal;

	if (*head == NULL) {
		return;
	}
	else {
		while (current != NULL) {
			index = current->next;

			while (index != NULL) {
				if (current->sal >index->sal) {
					strcpy(temp_id, current->id);
					strcpy(temp_name, current->name);
					temp_sal = current->sal;

					strcpy(current->id, index->id);
					strcpy(current->name, index->name);
					current->sal = index->sal;

					strcpy(index->id, temp_id);
					strcpy(index->name, temp_name);
					index->sal = temp_sal;
				}
				index = index->next;
			}
			current = current->next;
		}
	}
}

Salcount* concatenateLists(Salcount* list1, Salcount* list2)
{
	Salcount* temp = list1;

	if (temp == NULL) {
		return list2;
	}

	while (temp->next != NULL) {
		temp = temp->next;
	}

	temp->next = list2;

	return list1;
}


int main()
{
	Salcount* list1 = NULL;
	Salcount* list2 = NULL;
	int n1, n2;
	char ch;
	scanf("%d", &n1);
	ch = getchar();
	for (int i = 0; i < n1; i++)
	{
		appendnode(&list1);
	}
	scanf("%d", &n2);
	ch = getchar();
	for (int i = 0; i < n2; i++)
	{
		appendnode(&list2);
	}

	Salcount*final=concatenateLists(list1, list2);

	sortList(&final);

	printlist(final);
	printf("\n");

	sortList2(&final);
	printlist(final);
	return 0;
}