#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#pragma warning(disable:4996)

typedef struct
{
    int year;
    int month;
    int day;
}date;

int judge(date* p1, date* p2)
{
    if (p1->year > p2->year)
        return 0;
    else if (p1->year < p2->year)
        return 1;
    else if (p1->year == p2->year)
    {
        if (p1->month > p2->month)
            return 0;
        else if (p1->month < p2->month)
            return 1;
        else if (p1->month == p2->month)
        {
            if (p1->day > p2->day)
                return 0;
            else if (p1->day < p2->day)
                return 1;
            else return 1;
        }
    }
}

int yearday(int y)
{
    if ((y % 4 == 0 && y % 100 != 0) || (y % 400 == 0))
        return 366;
    else return 365;
}

int monthday(int y,int m)
{
    if (m == 1 || m == 3 || m == 5 || m == 7 || m == 8 || m == 10 || m == 12)
        return 31;
    else if (m == 2)
    {
        if (yearday(y) == 366)
            return 29;
        else return 28;
    }
    else return 30;
}

void exchange(date* p1, date* p2)
{
    date temp;
    temp.year = p1->year;
    temp.month = p1->month;
    temp.day = p1->day;

    p1->year = p2->year;
    p1->month = p2->month;
    p1->day = p2->day;

    p2->year = temp.year;
    p2->month = temp.month;
    p2->day = temp.day;
}

int compute(date* p1, date* p2)
{
    int days = 0;
    for (int i = (p1->year) + 1; i < p2->year; i++)
        days += yearday(i);
    if (p1->year < p2->year)
    {
        for (int i = (p1->month) + 1; i <= 12; i++)
            days += monthday(p1->year, i);
        for (int i = 1; i <= (p2->month) - 1; i++)
            days += monthday(p2->year, i);
    }
    else
    {
        if (p1->month < p2->month)
            for (int i = (p1->month) + 1; i <= (p2->month) - 1; i++)
                days += monthday(p1->year, i);
    }
    days += p2->day;
    days += monthday(p1->year, p1->month) - (p1->day);
    if ((p1->month == p2->month)&&(p1->year == p2->year))
        days = p2->day - p1->day;
    return days;
}

void Input(date* p)
{
    scanf("%d %d %d", &p->year, &p->month, &p->day);
}

int main()
{
    date date1, date2;
    Input(&date1);
    Input(&date2);
    if (judge(&date1, &date2) == 0)
        exchange(&date1, &date2);
    int days = compute(&date1, &date2);
    printf("%d", days);
	return 0;
}