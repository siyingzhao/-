#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#pragma warning(disable:4996)

typedef struct stu
{
	int num;
	struct stu* next;
}Stu;

Stu* createNode(int data);

Stu* createCircle(int N);

Stu* deleNode(Stu* delNode,Stu*prevNode);

int main()
{
	int N, m;
	scanf("%d", &N);
	scanf("%d", &m);

	Stu* current = createCircle(N);

	if (m >= 2)
	{
		while (N > 1)
		{
			Stu* prevNode = NULL;
			Stu* delNode = NULL;
			for (int count = 2; count <= m; count++)
			{
				prevNode = current;
				current = current->next;
				delNode = current;
			}
			current = deleNode(delNode, prevNode);
			N--;
			if (N == 1)
				break;
		}
	}

	else if (m == 1)
	{
		Stu* prevNode = NULL;
		Stu* delNode = NULL;

		for (int i = 1; i < N; i++)
		{
			if (i == 1)
				prevNode = current->next;
			else
				prevNode = prevNode->next;
		}
		while (N > 1)
		{
			delNode = current;
			current = deleNode(delNode, prevNode);
			N--;
			if (N == 1)
				break;
		}
	
	}

	printf("%d", current->num);

	free(current);
	return 0;
}

Stu* createNode(int num)
{
	Stu* newstu = (Stu*)malloc(sizeof(Stu));
	newstu->num = num;
	newstu->next = NULL;
	return newstu;
}

Stu* createCircle(int N)
{
	if (N == 0)
		return NULL;

	Stu* head = createNode(1);
	Stu* temp = head;

	for (int i = 2; i <= N; i++)
	{
		temp->next = createNode(i);
		temp = temp->next;
	}

	temp->next = head;
	return head;
}

Stu* deleNode(Stu* delNode, Stu* prevNode)
{
	prevNode->next = delNode->next;
	Stu* nextNode = delNode->next;
	free(delNode);
	return nextNode;
}