#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#pragma warning(disable:4996)

typedef struct
{
	char name[32];
	char stu_no[32];
	char birthplace[32];
	char age[10];
	char gender[10];
}Student;

Student students[130];

void input(Student *students,int size)
{
	for (int i = 0; i < size; i++)
	{
		char c = getchar();
		scanf("%[^,], %[^,], %[^,], %[^,], %[^\n]", students[i].name, students[i].stu_no, students[i].birthplace, students[i].age, students[i].gender);
	}

}

void output(Student* students, int size)
{
	for (int i = 0; i < size; i++)
	{
		printf("%s, %s, %s, %s, %s\n", students[i].name, students[i].stu_no, students[i].birthplace, students[i].age, students[i].gender);
	}
}

int match(const Student* student, const char keywords[5][32], int keywordCount)
{
	int match = 1;
	for (int i = 0; i < keywordCount; i++)
	{
		if (!(
			strstr(student->name, keywords[i]) ||
			strstr(student->stu_no, keywords[i]) ||
			strstr(student->birthplace, keywords[i]) ||
			strstr(student->age, keywords[i]) ||
			strstr(student->gender, keywords[i])
			))
		{
			match = 0;
			break;
		}
	}
	return match;
}

Student* findStudent(char* clue, Student* students,int size)
{
	char keywords[5][32];
	int keywordCount = 0;
	char* token = strtok(clue, ",");
	while (token != NULL && keywordCount < 5)
	{
		strcpy(keywords[keywordCount], token);
		keywordCount++;
		token = strtok(NULL, ",");
	}
	int flag = 0;
	int tag;
	for (int i = 0; i < size; i++)
	{
		if (match(&students[i], keywords, keywordCount))
		{
			flag++;
			tag = i;
		}
	}
	if (flag == 1)
		return &students[tag];
	else return NULL;

}

int main()
{
	int size;
	scanf("%d", &size);
	input(students, size);
	
	char clues[20][32];
	int count = 0;
	char c = getchar();
	while (count < 20)
	{
		if (fgets(clues[count], 32, stdin) == NULL)
		{
			break;
		}
		clues[count][strcspn(clues[count], "\n")] = 0;
		if (strcmp(clues[count], "quit") == 0) 
		{
			break;
		}
		count++;
	}
	output(students, size);
	for (int i = 0; i < count; i++)
	{
		Student* foundstudent = findStudent(clues[i], students, size);
		if (foundstudent != NULL)
			printf("%s, %s, %s, %s, %s\n", foundstudent->name, foundstudent->stu_no, foundstudent->birthplace, foundstudent->age, foundstudent->gender);
		else
			printf("error\n");
	}
	return 0;
}