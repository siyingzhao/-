#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#pragma warning(disable:4996)

void bubbleSort(int data[30][2], int count) {
	int temp;
	int pass = 1; bool exchange = true;             // �ӵ�һ�˿�ʼ
	while (pass < count && exchange) {
		exchange = false;                 // ĳ���Ƿ��н����ı�־����ʼΪ�޽���
		for (int j = count - 1; j >= pass; j--) //�����Ԫ�ؿ�ʼ����һ��δ����Ԫ��
			if (data[j - 1][0] > data[j][0]) {              //����Ҫ�������û�Ԫ��          
				temp = data[j - 1][0];
				data[j - 1][0] = data[j][0];
				data[j][0] = temp;

				temp = data[j - 1][1];
				data[j - 1][1] = data[j][1];
				data[j][1] = temp;
				exchange = true;
			}
		pass++;
	}
}

int main()
{
	int A[20][2], B[20][2], F[30][2];
	int countA = 0, countB = 0, countF = 0;
	char c;
	while (1)
	{
		scanf("%d %d", &A[countA][0], &A[countA][1]);
		c = getchar();
		if (A[countA][0] == 0)
			break;
		countA++;
	}
	while (1)
	{
		scanf("%d %d", &B[countB][0], &B[countB][1]);
		c = getchar();
		if (B[countB][0] == 0)
			break;
		countB++;
	}

	for (int i = 0; i < countA; i++)
	{
		int flag = 0;
		for (int j = 0; j < countB; j++)
		{
			if (A[i][0] == B[j][0])
			{
				F[countF][0] = A[i][0];
				F[countF][1] = (A[i][1] + B[j][1]) / 2;
				countF++;
				flag = 1;
			}
		}
		if (flag == 0)
		{
			F[countF][0] = A[i][0];
			F[countF][1] = A[i][1];
			countF++;
		}
	}
	for (int i = 0; i < countB; i++)
	{
		int flag = 0;
		for (int j = 0; j < countA; j++)
		{
			if (B[i][0] == A[j][0])
				flag = 1;
		}
		if (flag == 0)
		{
			F[countF][0] = B[i][0];
			F[countF][1] = B[i][1];
			countF++;
		}
	}

	bubbleSort(F, countF);
	int ymax = -100;
	for (int i = 0; i < countF; i++)
	{
		printf("%d %d\n", F[i][0], F[i][1]);
		if (ymax < F[i][1])
			ymax = F[i][1];
	}
	for (int i = 0; i < countF; i++)
	{
		if (F[i][1] == ymax)
			printf("(%d,%d)\n", F[i][0], F[i][1]);
	}
	return 0;
}