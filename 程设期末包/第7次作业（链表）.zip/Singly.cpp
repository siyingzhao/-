#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#pragma warning(disable:4996)

typedef struct stu
{
	int id;
	char name[21];
	struct stu* next;
}Stu;

Stu* creatnode(int id, const char* name)
{
	Stu* newnode = (Stu*)malloc(sizeof(Stu));
	if (!newnode)
	{
		printf("Error\n");
		exit(EXIT_FAILURE);
	}
	newnode->id = id;
	strcpy(newnode->name, name);

	newnode->next = NULL;
	return newnode;
}

int appendnode(Stu** head)
{
	char str[50];
	fgets(str, sizeof(str), stdin);
	str[strcspn(str, "\n")] = 0;
	int id;
	char name[21];
	int result = sscanf(str, "%d, %s", &id, name);
	if (result != 2)
		return id;
	Stu* newnode = creatnode(id, name);
	if (*head == NULL)
	{
		*head = newnode;
		return 2;
	}
	Stu* temp = *head;
	while (temp->next != NULL)
		temp = temp->next;
	temp->next = newnode;
	return result;
}

void sortList(Stu** head)
{
	Stu* current = *head, * index = NULL;
	char temp_name[21];
	int temp_id;

	if (*head == NULL) {
		return;
	}
	else {
		while (current != NULL) {
			index = current->next;

			while (index != NULL) {
				if (current->id > index->id) {
					strcpy(temp_name, current->name);
					temp_id = current->id;

					strcpy(current->name, index->name);
					current->id = index->id;

					strcpy(index->name, temp_name);
					index->id = temp_id;
				}
				index = index->next;
			}
			current = current->next;
		}
	}
}

void printReverse(Stu* head) 
{
	if (head == NULL) {
		return;
	}
	printReverse(head->next);
	printf("%d, %s\n", head->id, head->name);
}

int main()
{
	Stu* students = NULL;
	int result, node_count;
	result = appendnode(&students);
	node_count = 1;
	while (result == 2)
	{
		result = appendnode(&students);
		if (result == 2)
			node_count++;
	}

	sortList(&students);

	printf("%d\n", node_count);
	printReverse(students);

	Stu* prevNode = NULL;
	Stu* current = students;
	
	if (current->id == result)
	{
		printf("%d, %s\n", current->next->id, current->next->name);
		return 0;
	}

	while (1)
	{
		prevNode = current;
		current = current->next;
		if (current->id == result&&current->next!=NULL)
		{
			printf("%d, %s\n", prevNode->id, prevNode->name);
			printf("%d, %s\n", current->next->id, current->next->name);
			return 0;
		}
		if (current->id == result && current->next == NULL)
		{
			printf("%d, %s\n", prevNode->id, prevNode->name);
			return 0;
		}
		if (current->next == NULL)
			break;
	}
	printf("ERROR");
	return 0;
}