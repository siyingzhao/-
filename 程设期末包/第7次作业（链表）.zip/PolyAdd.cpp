#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#pragma warning(disable:4996)

typedef struct item
{
	int a;
	int n;
	struct item* next;
}Item;

Item* creatnode(int a,int n)
{
	Item* newnode = (Item*)malloc(sizeof(Item));
	newnode->a = a;
	newnode->n = n;
	newnode->next = NULL;
	return newnode;
}

void appendnode(Item** head)
{
	int a, n;
	char ch;
	scanf("%d %d", &a, &n);
	ch = getchar();
	Item* newnode = creatnode(a, n);
	if (*head == NULL)
	{
		*head = newnode;
		return;
	}
	Item* temp = *head;
	while (temp->next != NULL)
		temp = temp->next;
	temp->next = newnode;
}

void appendnode2(Item** head,int a,int n)
{
	Item* newnode = creatnode(a, n);
	if (*head == NULL)
	{
		*head = newnode;
		return;
	}
	Item* temp = *head;
	while (temp->next != NULL)
		temp = temp->next;
	temp->next = newnode;
}

Item* PolyAdd(Item* list1, Item* list2)
{
	Item* sumlist = NULL;
	while (list1 != NULL || list2 != NULL)
	{
		int suma;
		if (list1 == NULL&&list2!=NULL)
		{
			appendnode2(&sumlist, list2->a, list2->n);
			list2 = list2->next;
		}
		else if (list1 != NULL && list2 == NULL)
		{
			appendnode2(&sumlist, list1->a, list1->n);
			list1 = list1->next;
		}
		else if (list1->n == list2->n)
		{
			suma = list1->a + list2->a;
			appendnode2(&sumlist, suma, list1->n);
			list1 = list1->next;
			list2 = list2->next;
		}
		else if (list1->n < list2->n)
		{
			appendnode2(&sumlist, list1->a, list1->n);
			list1 = list1->next;
		}
		else if (list1->n > list2->n)
		{
			appendnode2(&sumlist, list2->a, list2->n);
			list2 = list2->next;
		}
	}
	return sumlist;
}

int count(Item* sumlist)
{
	int count = 0;
	Item* current = sumlist;
	while (current != NULL)
	{
		if (current->a != 0)
			count++;
		current = current->next;
	}
	return count;
}

void listprint(Item* list)
{
	Item* current = list;
	while (current != NULL)
	{
		if (current->a != 0)
			printf("%d %d\n", current->a, current->n);
		current = current->next;
	}
}

int main()
{
	Item* list1 = NULL;
	Item* list2 = NULL;
	int M1, M2;
	char ch;
	scanf("%d", &M1);
	ch = getchar();
	for (int i = 0; i < M1; i++)
		appendnode(&list1);
	scanf("%d", &M2);
	ch = getchar();
	for (int i = 0; i < M2; i++)
		appendnode(&list2);

	Item* sumlist = PolyAdd(list1, list2);
	int number = count(sumlist);

	printf("%d\n", number);
	listprint(sumlist);

	return 0;
}