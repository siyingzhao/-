#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#pragma warning(disable:4996)

void bubbleSort(int data[30][3], int count)
{
	int temp0, temp1, temp2;
	int pass = 1; bool exchange = true;             // �ӵ�һ�˿�ʼ
	while (pass < count && exchange) 
	{
		exchange = false;                 // ĳ���Ƿ��н����ı�־����ʼΪ�޽���
		for (int j = count - 1; j >= pass; j--) //�����Ԫ�ؿ�ʼ����һ��δ����Ԫ��
		{
			if (data[j - 1][0] < data[j][0])  //����Ҫ�������û�Ԫ�� 
			{
				temp0 = data[j - 1][0];
				data[j - 1][0] = data[j][0];
				data[j][0] = temp0;

				temp1 = data[j - 1][1];
				data[j - 1][1] = data[j][1];
				data[j][1] = temp1;

				temp2 = data[j - 1][2];
				data[j - 1][2] = data[j][2];
				data[j][2] = temp2;

				exchange = true;
			}
			else if (data[j - 1][0] == data[j][0])
			{
				if (data[j - 1][2] < data[j][2])
				{
					temp0 = data[j - 1][0];
					data[j - 1][0] = data[j][0];
					data[j][0] = temp0;

					temp1 = data[j - 1][1];
					data[j - 1][1] = data[j][1];
					data[j][1] = temp1;

					temp2 = data[j - 1][2];
					data[j - 1][2] = data[j][2];
					data[j][2] = temp2;

					exchange = true;
				}
				else if (data[j - 1][2] == data[j][2])
				{
					if (data[j - 1][1] < data[j][1])
					{
						temp0 = data[j - 1][0];
						data[j - 1][0] = data[j][0];
						data[j][0] = temp0;

						temp1 = data[j - 1][1];
						data[j - 1][1] = data[j][1];
						data[j][1] = temp1;

						temp2 = data[j - 1][2];
						data[j - 1][2] = data[j][2];
						data[j][2] = temp2;

						exchange = true;
					}
				}
			}
		}
		pass++;
	}
}

int main()
{
	char c;
	int num;

	int matrix1[25][3];
	int count1 = 0;
	for (int i = 0; i < 10; i++)
	{
		int j = 0;
		while (j < 10)
		{
			scanf("%d", &num);
			if (num != 0)
			{
				matrix1[count1][0] = num;
				matrix1[count1][1] = i;
				matrix1[count1][2] = j;
				count1++;
			}
			c = getchar();
			if (c == '\n')
				break;
			j++;
		}
	}

	int matrix2[25][3];
	int count2 = 0;
	for (int i = 0; i < 10; i++)
	{
		int j = 0;
		while (j < 10)
		{
			scanf("%d", &num);
			if (num != 0)
			{
				matrix2[count2][0] = num;
				matrix2[count2][1] = i;
				matrix2[count2][2] = j;
				count2++;
			}
			c = getchar();
			if (c == '\n')
				break;
			j++;
		}
	}

	int sum[30][3];
	int sumcount = 0;
	for (int i = 0; i < count1; i++)
	{
		int flag = 0;
		for (int j = 0; j < count2; j++)
		{
			if (
				(matrix1[i][1] == matrix2[j][1]) &&
				(matrix1[i][2] == matrix2[j][2])
				)
			{
				flag = 1;
				sum[sumcount][0] = matrix1[i][0] + matrix2[j][0];
				sum[sumcount][1] = matrix1[i][1];
				sum[sumcount][2] = matrix1[i][2];
				sumcount++;
			}
		}
		if (flag == 0)
		{
			sum[sumcount][0] = matrix1[i][0];
			sum[sumcount][1] = matrix1[i][1];
			sum[sumcount][2] = matrix1[i][2];
			sumcount++;
		}
	}

	for (int i = 0; i < count2; i++)
	{
		int flag = 0;
		for (int j = 0; j < count1; j++)
		{
			if (
				(matrix2[i][1] == matrix1[j][1]) &&
				(matrix2[i][2] == matrix1[j][2])
				)
			{
				flag = 1;
			}
		}
		if (flag == 0)
		{
			sum[sumcount][0] = matrix2[i][0];
			sum[sumcount][1] = matrix2[i][1];
			sum[sumcount][2] = matrix2[i][2];
			sumcount++;
		}
	}

	bubbleSort(sum, sumcount);

	if (sumcount % 2 == 1)
	{
		int p = (sumcount + 1) / 2;
		p--;
		p--;
		printf("%d,%d,%d", sum[p][0], sum[p][1]+1, sum[p][2]+1);
	}
	else if (sumcount % 2 == 0)
	{
		int p = sumcount / 2;
		p--;
		p--;
		printf("%d,%d,%d", sum[p][0], sum[p][1]+1, sum[p][2]+1);
	}
	return 0;
}